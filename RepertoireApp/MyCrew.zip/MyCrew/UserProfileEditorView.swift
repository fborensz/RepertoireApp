import SwiftUI

struct UserProfileEditorView: View {
    @Binding var userProfile: UserProfile
    @Environment(.dismiss) var dismiss

    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextField("Prénom", text: $userProfile.firstName)
                    TextField("Nom", text: $userProfile.lastName)
                    Picker("Métier", selection: $userProfile.jobTitle) {
                        ForEach(JobTitles.all, id: \.self) { job in
                            Text(job).tag(job)
                        }
                    }
                } header: {
                    Text("Identité")
                }

                Section {
                    TextField("Téléphone", text: $userProfile.phoneNumber)
                    TextField("Email", text: $userProfile.email)
                } header: {
                    Text("Contact")
                }

                Section {
                    ForEach(userProfile.locations.indices, id: \.self) { index in
                        VStack(alignment: .leading) {
                            Picker("Pays", selection: $userProfile.locations[index].country) {
                                ForEach(Locations.countries, id: \.self) { country in
                                    Text(country)
                                }
                            }
                            Picker("Région", selection: $userProfile.locations[index].region) {
                                ForEach(Locations.frenchRegions, id: \.self) { region in
                                    Text(region).tag(region)
                                }
                            }
                            Toggle("Résident local", isOn: $userProfile.locations[index].isLocalResident)
                            Toggle("Véhiculé", isOn: $userProfile.locations[index].hasVehicle)
                            Toggle("Logé", isOn: $userProfile.locations[index].isHoused)
                            Toggle("Lieu principal", isOn: $userProfile.locations[index].isPrimary)
                        }
                        .padding(.vertical, 4)
                    }
                    Button(action: {
                        userProfile.locations.append(Location.example)
                    }) {
                        Label("Ajouter un lieu", systemImage: "plus")
                    }
                } header: {
                    Text("Lieux de travail")
                }
            }
            .navigationTitle("Ma fiche pro")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") {
                        userProfile.save()
                        dismiss()
                    }
                }
            }
        }
    }
}
