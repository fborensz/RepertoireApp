import SwiftUI

struct RootView: View {
    @State private var userProfile = UserProfile.load() ?? UserProfile.example()
    var body: some View {
        VStack(spacing: 0) {
            // Header customisé
            HStack {
                
                Image("MyCrewLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                
                
                Text("Trouvez, contactez, tournez")
                    .font(.headline)
                    .foregroundColor(MyCrewColors.accent)
                    .padding(.leading, 12)

         
            }
            .padding(.vertical, 6) // réduit l'espace vertical (~70% de moins)
            .background(MyCrewColors.background)
            
            // Contenu de l'app
            
    VStack(spacing: 16) {
        UserProfileHeaderView(userProfile: $userProfile)
            .padding(.horizontal)
        NavigationView {
    
                ContentView()
                    .navigationBarHidden(false) // cache le titre système
            }
            .navigationViewStyle(StackNavigationViewStyle())
        }

            .accentColor(MyCrewColors.accent) // Force la couleur d'accent globale
            .background(MyCrewColors.background.ignoresSafeArea())
        }
        .background(MyCrewColors.background.ignoresSafeArea())
        .preferredColorScheme(.light) // Force le mode clair pour toute l'app
    }
}
