import SwiftUI

struct UserProfileHeaderView: View {
    @Binding var userProfile: UserProfile
    @State private var showEditor = false
    @State private var showQRCode = false

    var body: some View {
        HStack {
            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 30, height: 30)
                .foregroundColor(.white)

            VStack(alignment: .leading) {
                Text("MA FICHE PRO")
                    .font(.subheadline.weight(.bold))
                    .font(.system(size: 24))
                    .foregroundColor(Color(hex: "#2f3e34"))
                Text("\(userProfile.firstName) \(userProfile.lastName) • \(userProfile.jobTitle)")
                    .font(.caption)
                    .foregroundColor(.white)
            }
            Spacer()
            Image(uiImage: generateQRCode())
                .resizable()
                .frame(width: 40, height: 40)
                .onTapGesture {
                    showQRCode = true
                }
        }
        .padding()
        .padding(.horizontal, 12)
        .background(MyCrewColors.accentSecondary)
        .cornerRadius(12)
        .onTapGesture {
            showEditor = true
        }
        .sheet(isPresented: $showQRCode) {
            VStack {
                Image(uiImage: generateQRCode())
                    .resizable()
                    .interpolation(.none)
                    .scaledToFit()
                    .padding()
                Button("Fermer") {
                    showQRCode = false
                }
                .padding()
            }
            .background(MyCrewColors.accentSecondary)
        }
        .sheet(isPresented: $showEditor) {
            UserProfileEditorView(userProfile: $userProfile)
        }
    }

    private func generateQRCode() -> UIImage {
        let data = [
            "name": "\(userProfile.firstName) \(userProfile.lastName)",
            "jobTitle": userProfile.jobTitle,
            "phone": userProfile.phoneNumber,
            "email": userProfile.email
        ]

        if let json = try? JSONSerialization.data(withJSONObject: data),
           let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(json, forKey: "inputMessage")
            filter.setValue("Q", forKey: "inputCorrectionLevel")

            let transform = CGAffineTransform(scaleX: 10, y: 10)
            if let output = filter.outputImage?.transformed(by: transform) {
                let colored = output.applyingFilter("CIFalseColor", parameters: [
                    "inputColor0": CIColor(color: .white),  // QR en blanc
                    "inputColor1": CIColor(color: .clear)  // fond transparent
                ])
                let context = CIContext()
                if let cgImage = context.createCGImage(colored, from: colored.extent) {
                    return UIImage(cgImage: cgImage)
                }
            }
        }
        return UIImage()
    }
}
